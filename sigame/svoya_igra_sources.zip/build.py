from pathlib import Path
import re, math, json, zipfile, uuid, io
from lxml import etree as E
from PIL import Image, ImageDraw, ImageFont
BASE=Path(__file__).resolve().parent; OUT=BASE/'output'; OUT.mkdir(exist_ok=True); MEDIA=BASE/'media'; MEDIA.mkdir(exist_ok=True)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
def canvas():
 im=Image.new('RGB',(1280,800),'#f5f2e9');return im,ImageDraw.Draw(im)
def text(d,xy,s,size=48,fill='#172b3a',anchor='mm'):d.text(xy,s,font=ImageFont.truetype(font,size),fill=fill,anchor=anchor)
def save(im,n):im.save(MEDIA/n)
im,d=canvas();text(d,(640,400),'11',360);save(im,'number11.png')
im,d=canvas();d.rounded_rectangle((230,140,1050,660),30,fill='white',outline='#477482',width=7);text(d,(640,240),'МЕДИЦИНСКАЯ КАРТА',42);d.line((300,300,980,300),fill='#477482',width=3);text(d,(640,440),'AB (IV) Rh+',100);save(im,'blood.png')
im,d=canvas()
for y in range(8):
 for x in range(8):d.rectangle((180+x*75,100+y*75,255+x*75,175+y*75),fill='#e6cda0' if (x+y)%2==0 else '#684b39')
for x,y in [(215,138),(293,138),(306,140),(890,390),(940,410),(1000,455),(915,465),(950,490),(1020,390)]:d.ellipse((x-8,y-18,x+8,y+18),fill='#fff9dc',outline='#a78e63',width=2)
save(im,'rice.png')
im,d=canvas();pts=[]
for i in range(340):
 a=math.radians(i+12);pts.append((640+250*math.cos(a),400+250*math.sin(a)))
d.line(pts,fill='#315b44',width=65,joint='curve');d.polygon([(904,422),(855,490),(830,413)],fill='#315b44');d.ellipse((860,426,872,438),fill='#f5f2e9');save(im,'ouroboros.png')
im,d=canvas();d.arc((360,80,970,650),25,160,fill='#e8b923',width=105);d.arc((360,65,970,630),27,158,fill='#f6d94e',width=70);save(im,'banana.png')
source=(BASE/'source.txt').read_text()
blocks=re.split(r'КАТЕГОРИЯ \d+\. ',source)[1:7]
rows=[]
for block in blocks:
 name=block.splitlines()[0].strip();qs=[]
 for chunk in re.split(r'(?m)^(?:100|200|300|400|500) ОЧКОВ\s*$',block)[1:6]:
  q=re.search(r'Вопрос:\s*«(.*?)»[.\s]*(?:\n|$)',chunk,re.S).group(1)
  q=' '.join(q.split())
  a=re.search(r'(?:Ожидаемый ответ|Ответ):\s*(.*?)(?=\n\s*\n)',chunk,re.S).group(1);a=' '.join(a.split())
  alt=re.search(r'Допустимый ответ:\s*(.*?)(?=\n\s*\n)',chunk,re.S)
  ans=[a]+([' '.join(alt.group(1).split())] if alt else [])
  qs.append({'text':q,'answers':ans})
 rows.append({'name':name,'questions':qs})
# Media slots are explicitly separated by reveal stage.
slots={
(0,1):('half_life_barrel.png',None,'Оригинальное изображение красной взрывоопасной бочки из Half-Life'),
(0,4):('ouroboros.png',None,''),
(1,0):('harry_potter.jpg',None,'Кадр: Гарри Поттер, круглые очки и шрам'),
(1,2):(None,'vader_reveal.mp3','Оригинальная реплика No, I am your father'),
(1,3):('rick_morty_silhouettes.png',None,'Два чёрных узнаваемых силуэта Рика и Морти без лиц'),
(1,4):('matrix_pills.jpg','matrix_reveal.mp4','Кадр с Морфеусом и таблетками; короткая сцена после ответа'),
(2,0):(None,'billie_jean.mp3','Короткий фрагмент Billie Jean'),
(2,1):(None,'rickroll.mp3','Короткий фрагмент Never Gonna Give You Up'),
(2,2):(None,'kukla_kolduna.mp3','Короткий фрагмент Кукла колдуна'),
(2,3):('blood.png','gruppa_krovi.mp3','Короткое вступление Группа крови'),
(2,4):('tewiq_question.mp3','tewiq_reveal.mp3','Вокальный вход Сука, я походу попал; продолжение после ответа. Таймкод не проверен: исходника нет'),
(3,1):('bear_car.png','bear_car.mp3','Точный исходный мем не определён; требуется кадр и оригинальный звук'),
(3,2):('bear_forest.png',None,'Медведь в лесу с текстом Вся гипергамия ведёт к…'),
(3,3):('zhdun_question.png','zhdun_original.png','Ждун в вопросе; фото оригинальной скульптуры Homunculus loxodontus в ответе'),
(3,4):('number11.png',None,''),
(4,0):(None,'gagarin.png','Фотография Юрия Гагарина'),
(4,1):(None,'berlin_wall.png','Историческая фотография Берлинской стены'),
(4,2):('napoleon.png',None,'Наполеон Бонапарт верхом на коне, без подписей'),
(4,3):(None,'pompeii.png','Фотография раскопок Помпей'),
(4,4):(None,'magellan_route.png','Карта маршрута экспедиции Магеллана'),
(5,0):(None,'octopus.png','Изображение осьминога'),
(5,1):(None,'banana.png',''),
(5,3):('rice.png',None,''),
(5,4):(None,'platypus.png','Фотография утконоса')}
NS='https://github.com/VladimirKhil/SI/blob/master/assets/siq_5.xsd'
def el(parent,tag,text=None,**attrs):
 n=E.SubElement(parent,'{'+NS+'}'+tag,**attrs);n.text=text;return n
root=E.Element('{'+NS+'}package',nsmap={None:NS},name='Своя игра — тестовый первый раунд',version='5',id=str(uuid.uuid4()),language='ru-RU',date='09.11.2026',restriction='18+')
el(el(root,'info'),'comments','Технический прототип. Недостающие медиа обозначены явно. История и Неожиданные факты — временные категории. Ассоциативные ответы сохранены по заданию.')
rounds=el(root,'rounds');themes=el(el(rounds,'round',name='Первый раунд'),'themes');missing=[];used=set()
def item(p,s,**attrs):return el(p,'item',s,**attrs)
def media(p,filename,where,stage):
 path=MEDIA/filename
 if path.exists():
  kind='image' if path.suffix in ('.png','.jpg','.jpeg') else ('video' if path.suffix=='.mp4' else 'audio')
  item(p,filename,type=kind,isRef='True',placement='background' if kind=='audio' else 'screen',waitForFinish='True');used.add(filename)
 else:
  missing.append({'question':where,'stage':stage,'file':('Images/' if path.suffix in ('.png','.jpg') else 'Video/' if path.suffix=='.mp4' else 'Audio/')+filename})
  item(p,'[Отсутствует медиа: '+filename+']',type='text',placement='screen')
for ti,row in enumerate(rows):
 theme=el(themes,'theme',name=row['name']);questions=el(theme,'questions')
 for qi,data in enumerate(row['questions']):
  q=el(questions,'question',price=str((qi+1)*100))
  notes={(3,1):'Сгенерированная иллюстрация медведя в машине. Это не кадр исходного мема; исходный ролик не определён.',(3,3):'Изображения Ждуна сгенерированы: это иллюстрации скульптуры, не фотографии оригинала.',(4,0):'Сгенерированная иллюстрация Юрия Гагарина, не архивная фотография.',(4,1):'Сгенерированная историческая иллюстрация, не архивная фотография.',(4,2):'Сгенерированная картина по мотивам конного портрета Наполеона.',(4,3):'Сгенерированная иллюстрация Помпей, не документальная фотография.',(4,4):'Сгенерированная схематическая карта; линия маршрута приблизительная.',(1,4):'Кадр с руками Морфеуса: https://en.wikipedia.org/wiki/File:Morpheus_offering_pills.jpg',(1,0):'Изображение: https://x.com/Mega/status/1090449522420039686',(0,1):'Сгенерированная иллюстрация бочки в стиле Half-Life; не игровой скриншот.'}
  if (ti,qi) in notes:el(el(q,'info'),'comments',notes[(ti,qi)])
  params=el(q,'params')
  if (ti,qi)==(0,2):
   q.set('type','secret');el(params,'param','Игровые злодеи',name='theme');el(params,'param','exceptCurrent',name='selectionMode');el(el(params,'param',name='price',type='numberSet'),'numberSet',minimum='300',maximum='300',step='0')
  ask=el(params,'param',name='question',type='content');af,bf,desc=slots.get((ti,qi),(None,None,''))
  # Nonblocking text and following image share screen in SIQ 5.
  if af=='tewiq_question.mp3':media(ask,af,row['name']+' / '+str((qi+1)*100),'вопрос')
  item(ask,data['text'],type='text',placement='screen',waitForFinish='False' if af and af!='tewiq_question.mp3' else 'True')
  if af and af!='tewiq_question.mp3':media(ask,af,row['name']+' / '+str((qi+1)*100),'вопрос')
  reveal=el(params,'param',name='answer',type='content');item(reveal,data['answers'][0],type='text',waitForFinish='False' if bf else 'True')
  if bf:media(reveal,bf,row['name']+' / '+str((qi+1)*100),'ответ')
  if (ti,qi)==(3,2):item(reveal,'Вся гипергамия ведёт к медведям',type='text')
  if (ti,qi)==(3,4):item(reveal,'11.09.2001',type='text')
  right=el(q,'right')
  for a in data['answers']:el(right,'answer',a)
  if (ti,qi)==(5,3):
   for a in ['2^63','2⁶³','9 223 372 036 854 775 808']:el(right,'answer',a)
xml=E.tostring(root,encoding='utf-8',xml_declaration=True,pretty_print=True)
schema=E.XMLSchema(E.parse(str(BASE/'siq_5.xsd')));schema.assertValid(E.fromstring(xml))
OUT.joinpath('content.xml').write_bytes(xml)
ct=E.Element('Types',xmlns='http://schemas.openxmlformats.org/package/2006/content-types')
for ext,typ in [('xml','application/xml'),('png','image/png'),('jpg','image/jpeg'),('mp3','audio/mpeg'),('mp4','video/mp4')]:E.SubElement(ct,'Default',Extension=ext,ContentType=typ)
with zipfile.ZipFile(OUT/'svoya_igra_test_round_1.siq','w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('content.xml',xml);z.writestr('[Content_Types].xml',E.tostring(ct,xml_declaration=True,encoding='utf-8'))
 for name in sorted(used):z.write(MEDIA/name,'Images/'+name)
with zipfile.ZipFile(OUT/'svoya_igra_test_round_1.siq') as z:
 assert z.testzip() is None
 assert len(root.findall('.//{'+NS+'}theme'))==6
 for t in root.findall('.//{'+NS+'}theme'):
  qq=t.findall('.//{'+NS+'}question');assert [x.get('price') for x in qq]==['100','200','300','400','500']
 for n in used:
  im=Image.open(io.BytesIO(z.read('Images/'+n)));im.verify()
OUT.joinpath('missing_media.json').write_text(json.dumps(missing,ensure_ascii=False,indent=2))
print(json.dumps({'questions':sum(len(r['questions']) for r in rows),'images':len(used),'missing_slots':len(missing),'xsd':'PASS','zip_crc':'PASS'},ensure_ascii=False))
